﻿namespace Locacoes.Models
{
    public class Producer
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Pais { get; set; }
    }
}
